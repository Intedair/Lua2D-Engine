-- импорт встроенного плагина "composer" для работы со сценами
local composer = require("composer")
local scene = composer.newScene()

-- Точки и Размеры экрана
_DSCX = display.contentCenterX
_DSCY = display.contentCenterY
_DSH = display.contentHeight
_DSW = display.contentWidth


editor.objects = {}
editor.texts = {}


function scene:create()
  local editorScene = self.view
end
function scene.show()
  local editorScene = self.view
end
function scene.hide()
  local editorScene = self.view
end
function scene.destroy()
  local editorScene = self.view
end

return scene