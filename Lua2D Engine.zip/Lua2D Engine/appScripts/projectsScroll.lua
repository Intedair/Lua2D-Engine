
-- project scroll - все программы

-- константы точек экрана
_DSW = display.contentWidth
_DSH = display.contentHeight
_DSCX = display.contentCenterX
_DSCY = display.contentCenterY


-- импорты модулей
local json = require("json")
local composer = require("composer")

local scene = composer.newScene()



function scene:create(event)
  local projectsScrl = self.view
end  

function scene:show(event)
  local projectsScrl = self.view
end

function scene:hide(event)
  local projectsScrl = self.view
end

function scene:destroy(event)
  local projectsScrl = self.view
end

scene:addEventListener("create", scene)
scene:addEventListener("show", scene)
scene:addEventListener("hide", scene)
scene:addEventListener("destroy", scene)

return scene