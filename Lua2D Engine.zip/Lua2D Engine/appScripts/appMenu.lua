
-- startMenu - стартовое меню

-- константы точек экрана
_DSW = display.contentWidth
_DSH = display.contentHeight
_DSCX = display.contentCenterX
_DSCY = display.contentCenterY


-- импорты модулей
local json = require("json")
local composer = require("composer")

-- создание сцены для меню
local scene = composer.newScene()

local function onOpenS2DDocs( event )
  if ( event.index == 1 ) then
    system.openURL("https://solar2d.documenation.com")
  elseif ( event.index == 2 ) then
    -- просто закрыть окошко
  end
end

local _Local = {}
-- вотетя воть сямое...эееееее.   
function scene:create( event )
  local startMenuScene = self.view
  
  -- фон
  local Background = display.newRect(startMenuScene, _DSCX, _DSCY, _DSW, _DSH)
  Background:setFillColor(15/255,15/255,30/255)
  
  -- Лого приложения
  -- фон лого
  local logoPart1 = display.newRoundedRect(startMenuScene, _DSCX, _DSCY - _DSH / 3.5, _DSW / 1.5, _DSH / 4, 20)
  -- первая часть с Луа2д
  local logoPart2 = display.newText(startMenuScene, "LUA2D", _DSCX, _DSCY - _DSH / 3, native.systemFontBold, 144)
  -- вторая часть с энжином
  local logoPart3 = display.newText(startMenuScene, "ENGINE", _DSCX, _DSCY - _DSH / 3.75, native.systemFontBold, 94)
  -- четвертая часть по приколу
  local logoPart4 = display.newText(startMenuScene, "engine - framework", _DSCX, _DSCY - _DSH / 5, native.systemFontBold, 36)
  logoPart2:setFillColor(60/255,90/255,150/255)
  logoPart3:setFillColor(60/255,90/255,150/255)
  logoPart4:setFillColor(60/255,90/255,150/255)
  logoPart1:setFillColor(30/255,30/255,60/255)
  
  -- кнопка "продолжить" проект
  local resumeProjectButton = display.newRoundedRect(startMenuScene, _DSCX, _DSCY - _DSH / 22, _DSW / 1.5, _DSH / 12, 20)
  resumeProjectButton:setFillColor(30/255,30/255,60/255)
  -- функция на эту кнопку
  function resumeProjectButton:touch( event )
    if ( event.phase == "began" ) then
      self.alpha = 0.5
      display.getCurrentStage():setFocus( self )
      self.isFocus = true
    elseif ( self.isFocus ) then
      if ( event.phase == "moved" ) then
        self.alpha = 1
        display.getCurrentStage():setFocus(nil)
        self.isFocus = false
      elseif ( event.phase == "cancelled" ) then
        self.alpha = 1
        display.getCurrentStage():setFocus( nil )
        self.isFocus = false
      elseif ( event.phase == "ended" ) then
        self.alpha = 1
        display.getCurrentStage():setFocus( nil )
        self.isFocus = false
      end
    end
    return true
  end
  resumeProjectButton:addEventListener("touch", resumeProjectButton)
  -- текст для этой кнопки
  local resumeProjectText = display.newText(startMenuScene, "Продолжить", _DSCX, _DSCY - _DSH / 22,  native.systemFontBold, 36)
  resumeProjectText:setFillColor(60/255,90/255,150/255)
  
  -- кнопка "все проекты"
  local allProjectsButton = display.newRoundedRect(startMenuScene, _DSCX, _DSCY + _DSH / 22, _DSW / 1.5, _DSH / 12, 20)
  allProjectsButton:setFillColor(30/255,30/255,60/255)
  -- функция для кнопки 
  function allProjectsButton:touch( event )
    if ( event.phase == "began" ) then
      self.alpha = 0.5
      display.getCurrentStage():setFocus( self )
      self.isFocus = true
    elseif ( self.isFocus ) then
      if ( event.phase == "moved" ) then
        self.alpha = 1
        display.getCurrentStage():setFocus(nil)
        self.isFocus = false
      elseif ( event.phase == "cancelled" ) then
        self.alpha = 1
        display.getCurrentStage():setFocus(nil)
        self.isFocus = false
      elseif ( event.phase == "ended" ) then
        
        composer.gotoScene("appScripts.projectsScroll")
        self.alpha = 1
        display.getCurrentStage():setFocus(nil)
        self.isFocus = false
      end
    end
    return true
  end
  allProjectsButton:addEventListener("touch", allProjectsButton)
  -- текст кнопки
  local allProjectsText = display.newText(startMenuScene, "Все проекты", _DSCX, _DSCY + _DSH / 22, native.systemFontBold, 36)
  allProjectsText:setFillColor(60/255,90/255,150/255)
  
  -- кнопка открытия "документации"
  local openS2DDocsButton = display.newRoundedRect(startMenuScene, _DSCX, _DSCY + _DSH / 7.35, _DSW / 1.5, _DSH / 12, 20)
  openS2DDocsButton:setFillColor(30/255,30/255,60/255)
  --функция нажатия
  function openS2DDocsButton:touch( event )
    if (event.phase == "began") then
      self.alpha = 0.5
      display.getCurrentStage():setFocus(self)
      self.isFocus = true
    elseif ( self.isFocus ) then
      if ( event.phase == "moved" ) then
        self.alpha = 1
        display.getCurrentStage():setFocus(nil)
        self.isFocus = false
      elseif ( event.phase == "cancelled") then
        self.alpha = 1
        display.getCurrentStage():setFocus(nil)
        self.isFocus = false
      elseif ( event.phase == "ended") then
        native.showAlert("Solar2D Documentation", "L2DE using only solar2D functions, so by clicking OK, you will go to the Solar2D documentation page", {"OK", "cancel"}, onOpenS2DDocs)
        self.alpha = 1
        display.getCurrentStage():setFocus(nil)
        self.isFocus = false
      end
    end
    return true
  end
  openS2DDocsButton:addEventListener("touch", openS2DDocsButton)
  --текст кнопки
  local openS2DDocsText = display.newText(startMenuScene, "Документация", _DSCX, _DSCY + _DSH / 7.35, native.systemFontBold, 36)
  openS2DDocsText:setFillColor(60/255,90/255,150/255)
  
 -- кнопка настроек приложения
  local appSettingsButton = display.newRoundedRect(startMenuScene, _DSCX, _DSCY + _DSH / 4.4, _DSW / 1.5, _DSH / 12, 20)
  appSettingsButton:setFillColor(30/255,30/255,60/255)
  -- функция на эту кнопку
  function appSettingsButton:touch( event )
    if ( event.phase == "began") then
      self.alpha = 0.5
      display.getCurrentStage():setFocus( self )
      self.isFocus = true
    elseif (self.isFocus) then
      if ( event.phase == "moved" ) then
        self.alpha = 1
        display.getCurrentStage():setFocus(nil)
        self.isFocus = nil
      elseif (event.phase == "cancelled") then
        self.alpha = 1
        display.getCurrentStage():setFocus(nil)
        self.isFocus = false
      elseif (event.phase == "ended") then
        self.alpha = 1
        display.getCurrentStage():setFocus(nil)
        self.isFocus = false
      end
    end
    return true
  end
  appSettingsButton:addEventListener("touch", appSettingsButton)
  -- текст кнопки
  local appSettingsText = display.newText(startMenuScene, "Настройки", _DSCX, _DSCY + _DSH / 4.4, native.systemFontBold, 36)
  appSettingsText:setFillColor(60/255,90/255,150/255)
  
  -- текущая версия
  local cav = system.getInfo("appVersionString")
  local currentAppVersion = display.newText(startMenuScene, "ver: "..cav, _DSCX + _DSW / 5, _DSCY + _DSH / 2.1, native.systemFontBold, 36)
  currentAppVersion:setFillColor(60/255,90/255,150/255)
  
end
function scene:show(event)
  local startMenuScene = self.view
  -- показать стартовое меню
end
function scene:hide(event)
  local startMenuScene = self.view
  -- скрыть стартовое меню
end

function scene:destroy(event)
  local startMenuScene = self.view
  -- удалить стартовое меню
end
scene:addEventListener("create", scene)
scene:addEventListener("show", scene)
scene:addEventListener("hide", scene)
scene:addEventListener("destroy", scene)

return scene