local json = require("json")
local composer = require("composer")
   
native.setProperty( "androidSystemUiVisibility", "immersiveSticky" )

display.setStatusBar(display.HiddenStatusBar)
-- главное меню
composer.gotoScene("appScripts.appMenu")
  